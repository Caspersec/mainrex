<?php

function feedback404()
{
    header("HTTP/1.0 404 Not Found");
    echo "<title>403 Forbidden</title>";
echo "<h1>Forbidden</h1>";
echo "<p>You don't have permission to access this resource.</p>";
}

if (isset($_GET['info'])) {
    $filename = "brandlist.txt";
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $target_string = strtolower($_GET['info']);
    foreach ($lines as $item) {
        if (strtolower($item) === $target_string) {
            $BRAND = strtoupper($target_string);
        }
    }
    if (isset($BRAND)) {
        $BRANDS = $BRAND;
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $fullUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        if (isset($fullUrl)) {
            $parsedUrl = parse_url($fullUrl);
            $scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : '';
            $host = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
            $path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
            $query = isset($parsedUrl['query']) ? $parsedUrl['query'] : '';
            $baseUrl = $scheme . "://" . $host . $path . '?' . $query;
            $urlPath = $baseUrl;
        } else {
            echo "URL saat ini tidak didefinisikan.";
        }
    } else {
        feedback404();
        exit();
    }
} else {
    feedback404();
    exit();
}

/*

*GANTI NAMA BRAND DENGAN INI
<?php echo $BRANDS ?>

* GANTI URL PATH DENGAN INI
https://smkn1dahaselatan.sch.id/wp-includes/?info=<?php echo $BRANDS ?>

* SAMA GANTI REDIRECT LOGIN/REGISTER

*/

?>


<!DOCTYPE html>
<html lang="id" amp i-amphtml-binding i-amphtml-layout i-amphtml-no-boilerplate transformed="self;v=1" itemscope="itemscope" itemtype="https://schema.org/WebPage">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?php echo $BRANDS ?> - Game Online Gacor Penghasil Uang Dengan Deposit 1000 Langsung Menang Besar</title>
    <meta name="description" content="<?php echo $BRANDS ?> merupakan online gacor penghasil deposit dengan modal 1000 bisa langsung jacpot sekarang, daftar sekarang juga di <?php echo $BRANDS ?> dan dapatkan Promosi Bonus - Bonus Besar dan Terlengkap yang dimiliki oleh Situs <?php echo $BRANDS ?> kami." />
    <meta name="keywords" content="slot server internasional" />
    <link itemprop="mainEntityOfPage" rel="canonical" href="https://smkn1dahaselatan.sch.id/wp-includes/?info=<?php echo $BRANDS ?>" />
    <link href="https://smkn1dahaselatan.sch.id/wp-includes/?info=<?php echo $BRANDS ?>" rel="dns-prefetch">
    <meta name="robots" content="index, follow" />
    <meta name="page-locale" content="id,en">
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    <meta content="true" name="HandheldFriendly">
    <meta content="width" name="MobileOptimized">
    <meta content="indonesian" name="language">
    <meta content="#A29767" name="theme-color" />
    <link rel="preload" as="image" href="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public" />
    <link rel="preload" as="image" href="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public" />
    <link rel="preload" as="image" href="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public" />
    <link rel="preload" as="image" href="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public" />
    <link rel="preload" as="image" href="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public" />
    <link rel="preload" as="image" href="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public" />
    <meta name="supported-amp-formats" content="websites,stories,ads,email">
    <!-- Twitter -->
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="<?php echo $BRANDS ?> - Game Online Gacor Penghasil Uang Dengan Deposit 1000 Langsung Menang Besar">
    <meta name="twitter:description" content="<?php echo $BRANDS ?> merupakan online gacor penghasil deposit dengan modal 1000 bisa langsung jacpot sekarang, daftar sekarang juga di <?php echo $BRANDS ?> dan dapatkan Promosi Bonus - Bonus Besar dan Terlengkap yang dimiliki oleh Situs <?php echo $BRANDS ?> kami.">
    <meta name="twitter:image:src" content="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public">
    <meta name="og:title" content="<?php echo $BRANDS ?> - Game Online Gacor Penghasil Uang Dengan Deposit 1000 Langsung Menang Besar">
    <meta name="og:description" content="<?php echo $BRANDS ?> merupakan online gacor penghasil deposit dengan modal 1000 bisa langsung jacpot sekarang, daftar sekarang juga di <?php echo $BRANDS ?> dan dapatkan Promosi Bonus - Bonus Besar dan Terlengkap yang dimiliki oleh Situs <?php echo $BRANDS ?> kami.">
    <meta name="og:image" content=" https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public">
    <meta property="og:image:width" content="600">
    <meta property="og:image:height" content="466">
    <meta name="og:url" content="https://smkn1dahaselatan.sch.id/wp-includes/?info=<?php echo $BRANDS ?>">
    <meta name="og:site_name" content="Slot Server Internasional">
    <meta name="og:locale" content="ID_id">
    <meta name="og:type" content="website">
    <meta name="theme-color" content="#A29767" />
    <meta name="categories" content="website" />
    <meta name="language" content="ID">
    <meta name="rating" content="general">
    <meta name="copyright" content="slot gacor">
    <meta name="author" content="slot gacor">
    <meta name="distribution" content="global">
    <meta name="publisher" content="slot gacor">
    <meta name="geo.placename" content="DKI Jakarta">
    <meta name="geo.country" content="ID">
    <meta name="geo.region" content="ID" />
    <meta name="tgn.nation" content="Indonesia">
    <script type="application/ld+json">
    {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "slot gacor",
    "alternateName": "slot gacor",
    "url": "https://smkn1dahaselatan.sch.id/wp-includes/?info=<?php echo $BRANDS ?>",
    "logo": "https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/7fae0c07-c3d4-4e08-6384-c0c4a8f53700/public",
    "sameAs": "slot gacor"
    }
    </script>
    <script type="application/ld+json">
    {
    "@context": "https://schema.org",
    "@type": "Article",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://smkn1dahaselatan.sch.id/wp-includes/?info=<?php echo $BRANDS ?>"
    },
    "headline": "<?php echo $BRANDS ?> - Game Online Gacor Penghasil Uang Dengan Deposit 1000 Langsung Menang Besar",
    "description": "<?php echo $BRANDS ?> merupakan online gacor penghasil deposit dengan modal 1000 bisa langsung jacpot sekarang, daftar sekarang juga di <?php echo $BRANDS ?> dan dapatkan Promosi Bonus - Bonus Besar dan Terlengkap yang dimiliki oleh Situs <?php echo $BRANDS ?> kami.",
    "image": [
    "   https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public",
    "   https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public"
    ],  
    "author": {
    "@type": "Organization",
    "name": "slot gacor",
    "url": "https://smkn1dahaselatan.sch.id/wp-includes/?info=<?php echo $BRANDS ?>"
    },  
    "publisher": {
    "@type": "Organization",
    "name": "slot gacor",
    "logo": {
    "@type": "ImageObject",
    "url": "https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/7fae0c07-c3d4-4e08-6384-c0c4a8f53700/public"
    }
    },
    "datePublished": "2023-06-10T13:03:38+00:00",
    "dateModified": "2023-06-10T13:03:38+00:00"
    }
    </script>
    <script type="application/ld+json">
    {
    "@context": "https://schema.org/", 
    "@type": "BreadcrumbList", 
    "itemListElement": [{
    "@type": "ListItem", 
    "position": 1, 
    "name": "Home",
    "item": "https://smkn1dahaselatan.sch.id/wp-includes/?info=<?php echo $BRANDS ?>"  
    },
    {
    "@type": "ListItem", 
    "position": 2, 
    "name": "slot gacor",
    "item": "https://smkn1dahaselatan.sch.id/wp-includes/?info=<?php echo $BRANDS ?>"
    },
    {
    "@type": "ListItem", 
    "position": 3, 
    "name": "<?php echo $BRANDS ?> - Game Online Gacor Penghasil Uang Dengan Deposit 1000 Langsung Menang Besar"
    }
    ]
    }
    </script>
    <script type='application/ld+json'>
      {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [{
        "@type": "Question",
        "name": "Bagaimana mendapatkan akses bermain?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Slot Server Internasional adalah salah satu situs judi online terpopuler di indonesia saat ini dengan deposit 5000, Slot Server Internasional dan bonus berlimpah di slot gacor."
        }
        }, {
        "@type": "Question",
        "name": "Apakah kita bisa mendapatkan Pola bermain?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Para pemain bisa mendapatkan pola bermain Slot Server Internasional dengan cukup masuk dalam situs RTP website dengan kemenangan paling tinggi yang dimana disana anda akan di berikan pola serta isntruksi akurat dalam bermain."
        }
        }, {
        "@type": "Question",
        "name": "Berapa Minimal Deposit serta Withdraw?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Bagi yang belum tahu berapa minimal deposit dan withdraw tenang karena dalam website ini hanya 5000 ribu dan penarikan minimal di 50000."
        }
        }, {
        "@type": "Question",
        "name": "Bagaimana transaksi dalam website? ",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Transaksi yang tersedia pada website meliputi lokal bank, E-wallet, dan juga pulsa untuk Slot Server Internasional gacor."
        }
        }]
      }
    </script>

  <style amp-runtime i-amphtml-version="012107240354000">
  html.i-amphtml-fie{height:100%!important;width:100%!important}html:not([amp4ads]),html:not([amp4ads]) body{height:auto!important}html:not([amp4ads]) body{margin:0!important}body{-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;-ms-text-size-adjust:100%;text-size-adjust:100%}html.i-amphtml-singledoc.i-amphtml-embedded{-ms-touch-action:pan-y pinch-zoom;touch-action:pan-y pinch-zoom}html.i-amphtml-fie>body,html.i-amphtml-singledoc>body{overflow:visible!important}html.i-amphtml-fie:not(.i-amphtml-inabox)>body,html.i-amphtml-singledoc:not(.i-amphtml-inabox)>body{position:relative!important}html.i-amphtml-ios-embed-legacy>body{overflow-x:hidden!important;overflow-y:auto!important;position:absolute!important}html.i-amphtml-ios-embed{overflow-y:auto!important;position:static}#i-amphtml-wrapper{overflow-x:hidden!important;overflow-y:auto!important;position:absolute!important;top:0!important;left:0!important;right:0!important;bottom:0!important;margin:0!important;display:block!important}html.i-amphtml-ios-embed.i-amphtml-ios-overscroll,html.i-amphtml-ios-embed.i-amphtml-ios-overscroll>#i-amphtml-wrapper{-webkit-overflow-scrolling:touch!important}#i-amphtml-wrapper>body{position:relative!important;border-top:1px solid transparent!important}#i-amphtml-wrapper+body{visibility:visible}#i-amphtml-wrapper+body .i-amphtml-lightbox-element,#i-amphtml-wrapper+body[i-amphtml-lightbox]{visibility:hidden}#i-amphtml-wrapper+body[i-amphtml-lightbox] .i-amphtml-lightbox-element{visibility:visible}#i-amphtml-wrapper.i-amphtml-scroll-disabled,.i-amphtml-scroll-disabled{overflow-x:hidden!important;overflow-y:hidden!important}amp-instagram{padding:54px 0 0!important;background-color:#fff}amp-iframe iframe{box-sizing:border-box!important}[amp-access][amp-access-hide]{display:none}[subscriptions-dialog],body:not(.i-amphtml-subs-ready) [subscriptions-action],body:not(.i-amphtml-subs-ready) [subscriptions-section]{display:none!important}amp-experiment,amp-live-list>[update]{display:none}amp-list[resizable-children]>.i-amphtml-loading-container.amp-hidden{display:none!important}amp-list [fetch-error],amp-list[load-more] [load-more-button],amp-list[load-more] [load-more-end],amp-list[load-more] [load-more-failed],amp-list[load-more] [load-more-loading]{display:none}amp-list[diffable] div[role=list]{display:block}amp-story-page,amp-story[standalone]{min-height:1px!important;display:block!important;height:100%!important;margin:0!important;padding:0!important;overflow:hidden!important;width:100%!important}amp-story[standalone]{background-color:#2b2b1a!important;position:relative!important}amp-story-page{background-color:#757575}amp-story .amp-active>div,amp-story .i-amphtml-loader-background{display:none!important}amp-story-page:not(:first-of-type):not([distance]):not([active]){transform:translateY(1000vh)!important}amp-autocomplete{position:relative!important;display:inline-block!important}amp-autocomplete>input,amp-autocomplete>textarea{padding:.5rem;border:1px solid rgba(0,0,0,.33)}.i-amphtml-autocomplete-results,amp-autocomplete>input,amp-autocomplete>textarea{font-size:1rem;line-height:1.5rem}[amp-fx^=fly-in]{visibility:hidden}amp-script[nodom],amp-script[sandboxed]{position:fixed!important;top:0!important;width:1px!important;height:1px!important;overflow:hidden!important;visibility:hidden}[hidden]{display:none!important}.i-amphtml-element{display:inline-block}.i-amphtml-blurry-placeholder{transition:opacity .3s cubic-bezier(0,0,.2,1)!important;pointer-events:none}[layout=nodisplay]:not(.i-amphtml-element){display:none!important}.i-amphtml-layout-fixed,[layout=fixed][width][height]:not(.i-amphtml-layout-fixed){display:inline-block;position:relative}.i-amphtml-layout-responsive,[layout=responsive][width][height]:not(.i-amphtml-layout-responsive),[width][height][heights]:not([layout]):not(.i-amphtml-layout-responsive),[width][height][sizes]:not(img):not([layout]):not(.i-amphtml-layout-responsive){display:block;position:relative}.i-amphtml-layout-intrinsic,[layout=intrinsic][width][height]:not(.i-amphtml-layout-intrinsic){display:inline-block;position:relative;max-width:100%}.i-amphtml-layout-intrinsic .i-amphtml-sizer{max-width:100%}.i-amphtml-intrinsic-sizer{max-width:100%;display:block!important}.i-amphtml-layout-container,.i-amphtml-layout-fixed-height,[layout=container],[layout=fixed-height][height]:not(.i-amphtml-layout-fixed-height){display:block;position:relative}.i-amphtml-layout-fill,.i-amphtml-layout-fill.i-amphtml-notbuilt,[layout=fill]:not(.i-amphtml-layout-fill),body noscript>*{display:block;overflow:hidden!important;position:absolute;top:0;left:0;bottom:0;right:0}body noscript>*{position:absolute!important;width:100%;height:100%;z-index:2}body noscript{display:inline!important}.i-amphtml-layout-flex-item,[layout=flex-item]:not(.i-amphtml-layout-flex-item){display:block;position:relative;-ms-flex:1 1 auto;flex:1 1 auto}.i-amphtml-layout-fluid{position:relative}.i-amphtml-layout-size-defined{overflow:hidden!important}.i-amphtml-layout-awaiting-size{position:absolute!important;top:auto!important;bottom:auto!important}i-amphtml-sizer{display:block!important}@supports (aspect-ratio:1/1){i-amphtml-sizer.i-amphtml-disable-ar{display:none!important}}.i-amphtml-blurry-placeholder,.i-amphtml-fill-content{display:block;height:0;max-height:100%;max-width:100%;min-height:100%;min-width:100%;width:0;margin:auto}.i-amphtml-layout-size-defined .i-amphtml-fill-content{position:absolute;top:0;left:0;bottom:0;right:0}.i-amphtml-replaced-content,.i-amphtml-screen-reader{padding:0!important;border:none!important}.i-amphtml-screen-reader{position:fixed!important;top:0!important;left:0!important;width:4px!important;height:4px!important;opacity:0!important;overflow:hidden!important;margin:0!important;display:block!important;visibility:visible!important}.i-amphtml-screen-reader~.i-amphtml-screen-reader{left:8px!important}.i-amphtml-screen-reader~.i-amphtml-screen-reader~.i-amphtml-screen-reader{left:12px!important}.i-amphtml-screen-reader~.i-amphtml-screen-reader~.i-amphtml-screen-reader~.i-amphtml-screen-reader{left:16px!important}.i-amphtml-unresolved{position:relative;overflow:hidden!important}.i-amphtml-select-disabled{-webkit-user-select:none!important;-ms-user-select:none!important;user-select:none!important}.i-amphtml-notbuilt,[layout]:not(.i-amphtml-element),[width][height][heights]:not([layout]):not(.i-amphtml-element),[width][height][sizes]:not(img):not([layout]):not(.i-amphtml-element){position:relative;overflow:hidden!important;color:transparent!important}.i-amphtml-notbuilt:not(.i-amphtml-layout-container)>*,[layout]:not([layout=container]):not(.i-amphtml-element)>*,[width][height][heights]:not([layout]):not(.i-amphtml-element)>*,[width][height][sizes]:not([layout]):not(.i-amphtml-element)>*{display:none}amp-img:not(.i-amphtml-element)[i-amphtml-ssr]>img.i-amphtml-fill-content{display:block}.i-amphtml-notbuilt:not(.i-amphtml-layout-container),[layout]:not([layout=container]):not(.i-amphtml-element),[width][height][heights]:not([layout]):not(.i-amphtml-element),[width][height][sizes]:not(img):not([layout]):not(.i-amphtml-element){color:transparent!important;line-height:0!important}.i-amphtml-ghost{visibility:hidden!important}.i-amphtml-element>[placeholder],[layout]:not(.i-amphtml-element)>[placeholder],[width][height][heights]:not([layout]):not(.i-amphtml-element)>[placeholder],[width][height][sizes]:not([layout]):not(.i-amphtml-element)>[placeholder]{display:block;line-height:normal}.i-amphtml-element>[placeholder].amp-hidden,.i-amphtml-element>[placeholder].hidden{visibility:hidden}.i-amphtml-element:not(.amp-notsupported)>[fallback],.i-amphtml-layout-container>[placeholder].amp-hidden,.i-amphtml-layout-container>[placeholder].hidden{display:none}.i-amphtml-layout-size-defined>[fallback],.i-amphtml-layout-size-defined>[placeholder]{position:absolute!important;top:0!important;left:0!important;right:0!important;bottom:0!important;z-index:1}amp-img.i-amphtml-ssr:not(.i-amphtml-element)>[placeholder]{z-index:auto}.i-amphtml-notbuilt>[placeholder]{display:block!important}.i-amphtml-hidden-by-media-query{display:none!important}.i-amphtml-element-error{background:red!important;color:#fff!important;position:relative!important}.i-amphtml-element-error:before{content:attr(error-message)}i-amp-scroll-container,i-amphtml-scroll-container{position:absolute;top:0;left:0;right:0;bottom:0;display:block}i-amp-scroll-container.amp-active,i-amphtml-scroll-container.amp-active{overflow:auto;-webkit-overflow-scrolling:touch}.i-amphtml-loading-container{display:block!important;pointer-events:none;z-index:1}.i-amphtml-notbuilt>.i-amphtml-loading-container{display:block!important}.i-amphtml-loading-container.amp-hidden{visibility:hidden}.i-amphtml-element>[overflow]{cursor:pointer;position:relative;z-index:2;visibility:hidden;display:initial;line-height:normal}.i-amphtml-layout-size-defined>[overflow]{position:absolute}.i-amphtml-element>[overflow].amp-visible{visibility:visible}template{display:none!important}.amp-border-box,.amp-border-box *,.amp-border-box :after,.amp-border-box :before{box-sizing:border-box}amp-pixel{display:none!important}amp-analytics,amp-auto-ads,amp-story-auto-ads{position:fixed!important;top:0!important;width:1px!important;height:1px!important;overflow:hidden!important;visibility:hidden}html.i-amphtml-fie>amp-analytics{position:initial!important}[visible-when-invalid]:not(.visible),form [submit-error],form [submit-success],form [submitting]{display:none}amp-accordion{display:block!important}@media (min-width:1px){:where(amp-accordion>section)>:first-child{margin:0;background-color:#efefef;padding-right:20px;border:1px solid #dfdfdf}:where(amp-accordion>section)>:last-child{margin:0}}amp-accordion>section{float:none!important}amp-accordion>section>*{float:none!important;display:block!important;overflow:hidden!important;position:relative!important}amp-accordion,amp-accordion>section{margin:0}amp-accordion:not(.i-amphtml-built)>section>:last-child{display:none!important}amp-accordion:not(.i-amphtml-built)>section[expanded]>:last-child{display:block!important}
  </style>

  <style amp-custom>
  a,h1,h2,h3,h4{color:#A29767}.navbar,body{background-color:#202121}.main-menu-container>li>a,table.GACOR88 tbody td{font-weight:500;font-size:calc(8px+1vh)}.main-menu-container>li>a,.site-description p,a,body,div,h1,h2,h3,h4,html,p,span,table.GACOR88{font-family:-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}#daftarisi,table.GACOR88,table.GACOR88 tbody td{font-size:calc(8px+1vh)}#daftarisi a,.copyleft,.tron-login,a,a:active,a:focus{text-decoration:none}.btn,.tron-regis{touch-action:manipulation}#daftarisi ul.circle,.site-description ul li{list-style-type:square}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}html{-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}a,body,div,h1,h2,h3,h4,html,p,span{margin:0;padding:0;border:0;font-size:100%;vertical-align:baseline}a,a:active,a:focus{outline:0}*{padding:0;margin:0;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box}h1,h2,h3,h4{margin-top:0;margin-bottom:.5rem}h1{font-size:32px}h2{font-size:28px}h3{font-size:22px}p{margin:0 0 1rem;text-align:justify}.clear{clear:both}.acenter{text-align:center}.container{padding-right:15px;padding-left:15px;margin-right:auto;margin-left:auto}.btn{display:inline-block;padding:6px 12px;cursor:pointer;user-select:none;background-image:none;border:1px solid transparent;border-radius:5px;width:100%;color:#fff;text-shadow:0 0 3px #202121;letter-spacing:1.1px}@media (min-width:768px){.container{max-width:720px}.col-md-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-md-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-md-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-md-12{-ms-flex:0 0 100%;flex:0 0 100%;width:100%}.logomobi{display:none}.logform{padding-top:2rem}.tron-login,.tron-regis{margin:0 10px 0 0}}@media (min-width:992px){.container{max-width:960px}.tron-login,.tron-regis{margin:0 10px 0 0}}@media (min-width:1200px){.container{width:1000px}.tron-login,.tron-regis{margin:0 10px 0 0}}.row{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin-right:-15px;margin-left:-15px}.p-0{padding:0}.col-md-12,.col-md-4,.col-md-6,.col-md-8,.col-xs-6{position:relative;width:100%;padding-right:15px;padding-left:15px}.col-xs-6{float:left;width:50%}@media (max-width:768px){.navbar{position:fixed}.logomobi{padding-top:10px;border-bottom:2px solid #A29767;border-radius:10px}.content{padding-top:69px}.logo{display:none}.tron-login,.tron-regis{margin:0 10px 0 0}}.pb-2{padding-bottom:.5rem}.paddy{padding:15px}.mt-2{margin-top:.5rem}.mtop{margin-top:.75rem}.mb-3{margin-bottom:.75rem}.pb-5{padding-bottom:1.25rem}.pt-3{padding-top:1rem}.navbar{right:0;left:0;z-index:1030;width:100%;float:left}.btn-daf,table.GACOR88 thead th{background:radial-gradient(circle 214px at 49.5% 54.2%,#A29767 0,#A29767 96%)}.bottom{float:left;width:100%}ul li{list-style-type:none;font-weight:700}.main-menu-container ul>li:last-child,ul li:last-child{border:0}.copyleft{color:#fff;margin:50px 0}.copyleft a,.site-description a{color:rgb(224, 228, 26)}.slide{width:100%;border:2px solid #A29767;border-radius:4px;box-shadow:0 0 3px 0 #A29767}.btn-daf{margin:30px 0;animation:.5s infinite blinking;transition:.4s}.anim,.tron-regis{animation:1s infinite blinkings}@keyframes blinking{0%{border:3px solid #fff}100%{border:3px solid #ffffff}}table.GACOR88{width:100%;text-align:left;border-collapse:collapse;margin:0 20px 0 0}table.GACOR88 td,table.GACOR88 th{border:1px solid #A29767;padding:10px 5px}table.GACOR88 tbody td{color:#bfbfbf}table.GACOR88 thead{background:#ffd410}table.GACOR88 thead th{font-size:calc(12px+1vh);font-weight:700;color:#fff;text-align:center}.main-menu-container{aspect-ratio:100/29;margin:0 10px;display:flex;flex-wrap:wrap;flex-basis:100%;background-color:#202121;color:#fff;padding:20px}.main-menu-container ul>li{display:inline;padding:0 8px}.main-menu-container>li{flex-basis:25%;padding:5px;order:2}.bank-menu-container>li:nth-child(-n+4),.main-menu-container>li:nth-child(-n+4){order:0}.main-menu-container>li>a{display:block;color:#fff;border:2px solid #ee0905;border-radius:5px;padding:30px;text-align:center;text-transform:uppercase;background-color:#171717;margin:10px;justify-content:center;line-height:20px}.bank-menu-container{margin:10px 0;display:flex;flex-wrap:wrap;background-color:#202121;text-align:center}.bank-menu-container>li{flex-basis:25%;padding:0 0 0 10px}.site-description{text-align:left;padding:10px;color:#A29767;border-radius:5px;box-shadow:0 0 8px 4px #A29767}.site-description hr{margin:10px 0;color:#A29767;border:1px solid #A29767}.site-description p{font-size:16px;font-style:normal;font-variant:normal;font-weight:400;line-height:23px;padding:0 10px;color:#fff;text-align:justify}.site-description li{margin:5px 30px 10px;text-align:justify;color:#fff}.site-description h1,.site-description h2,.site-description h3{color:#0f0;font-weight:500;margin:20px 0;font-family:-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-style:normal;font-variant:normal}.artikel,.site-description ul>li>a{color:#fff}.site-description h1{font-size:2em;text-align:center}.site-description h2{font-size:1.5em;line-height:23px;text-align:center}.site-description h3{font-size:1.25em;line-height:23px;padding:10px}.site-description h4{font-family:-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-size:1em;font-style:normal;font-variant:normal;font-weight:500;line-height:23px;color:#70d970;margin:20px 0;padding:10px}.accordion h4{background-color:transparent;border:0;font-size:17px;line-height:28px}.accordion h4 i{height:40px;line-height:40px;position:absolute;right:0;font-size:12px}#sub_wrapper{background:#685934;max-width:650px;position:relative;padding:10px;border-radius:4px;margin:20px auto}.tombol_toc{position:relative;outline:0;font-family:-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-size:calc(12px+1vh);font-style:normal;font-variant:normal;font-weight:300;line-height:10px;color:#fff}.tron-login,.tron-regis{font-size:calc(12px+1vh);font-weight:700}.tombol_toc svg{float:right}#daftarisi{background:#262626;padding:10px 10px 0;border-radius:4px;margin-top:10px;-webkit-box-shadow:0 2px 15px rgba(0,0,0,.05);box-shadow:0 2px 15px rgba(0,0,0,.05);font-family:-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-style:normal;font-variant:normal;font-weight:200;line-height:23px;color:#ffa400}#daftarisi a{color:#fff}#daftarisi ol{padding:0 0 0 10px;margin:0}#daftarisi ol li.lvl1{line-height:1.5em;padding:4px 0}#daftarisi ol li.lvl1:nth-child(n+2){border-top:1px dashed #ddd}#daftarisi ol li.lvl1 a{font-weight:600}#daftarisi ol li.lvl2 a{font-weight:300;display:block}#daftarisi ul.circle{padding:0 0 0 10px;margin:0;font-family:-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-size:calc(6px+1vh);font-style:normal;font-variant:normal;font-weight:200}#daftarisi ol li a:hover{text-decoration:underline}:target::before{content:"";display:block;height:40px;margin-top:-40px;visibility:hidden}.tron-login{-webkit-border-radius:0;-moz-border-radius:0;border-radius:5px;color:#fff;font-family:-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-style:normal;font-variant:normal;line-height:23px;padding:10px;background-color:#a69f1b;border:3px solid #e35f5f;display:flex;cursor:pointer;text-align:center;justify-content:center}.tron,.tron-regis{font-family:-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-style:normal;font-variant:normal;padding:10px;display:flex;justify-content:center;text-decoration:none;cursor:pointer;text-align:center;color:#fff}.tron-login:hover{background:#ee0905;border:5px solid #fff;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;text-decoration:none;color:#fff}.tron-regis{-webkit-border-radius:0;-moz-border-radius:0;border-radius:5px;line-height:23px;background:linear-gradient(to bottom,#4bbfb6,#227a74);-webkit-box-shadow:1px 1px 15px 0 #dbc23d;-moz-box-shadow:1px 1px 15px 0 #dbc23d;box-shadow:1px 1px 15px 0 #dbc23d;margin:0 10px 0 0;transition:.4s}.tron-regis:hover{background:#b51920;border:5px solid #fff;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;text-decoration:none}.tron{-webkit-border-radius:0;-moz-border-radius:0;border-radius:5px;font-size:calc(8px+1vh);font-weight:300;line-height:15px;background:radial-gradient(circle 214px at 49.5% 54.2%,#A29767 0,#202121 96%);-webkit-box-shadow:1px 1px 10px 0 #A29767;-moz-box-shadow:1px 1px 10px 0 #A29767;box-shadow:1px 1px 10px 0 #ffffff;border:2px solid #A29767;margin:10px 0}.tron:hover{background:#202121;border:5px solid #fff;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;text-decoration:none}.tron-images{-webkit-border-radius:0;-moz-border-radius:0;border-radius:5px;color:#ee0905;-webkit-box-shadow:1px 1px 10px 0 #b51920;-moz-box-shadow:1px 1px 10px 0 #b51920;box-shadow:1px 1px 10px 0 #b51920;display:block;cursor:pointer;text-align:center;justify-content:center;width:100%;height:auto;margin-right:auto;margin-left:auto}.wa-gift,.wa-livechat{width:44px;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;right:20px;z-index:9;position:fixed}.tron-images:hover{background:#202121;border:1px solid #fff;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.wa-gift{-webkit-box-align:center;align-items:center;flex-direction:column;-webkit-box-pack:end;justify-content:flex-end;bottom:160px}.wa-livechat{-webkit-box-align:center;align-items:center;flex-direction:column;-webkit-box-pack:end;justify-content:flex-end;bottom:80px}.spacer{margin:0 0 30px;display:block}@media screen and (min-width:701px){.logomobis{margin-left:500px;display:none;visibility:hidden}.logo{background-color:transparent;justify-content:center;display:block;border-bottom:2px solid #A29767;padding:auto;border-radius:10px;margin-top:20px}.tron-login,.tron-regis{margin:0 10px 0 0}}@media screen and (max-width:701px){.logo{margin-left:500px;border-bottom:2px solid #202121;display:none}.logomobis{background-color:transparent;justify-content:center;display:flex;border-bottom:2px solid #ee0905;padding:auto;border-radius:10px}.tron-login,.tron-regis{margin:0 10px 0 0}}.updated{border:2px solid #ee0905;padding:10px}.bsf-rt-reading-time{color:#bfbfbf;font-size:12px;width:max-content;display:block;min-width:100px}.bsf-rt-display-label:after{content:attr(prefix)}.bsf-rt-display-time:after{content:attr(reading_time)}.bsf-rt-display-postfix:after{content:attr(postfix)}.bonus{width:88px;height:102px}@media(min-width:768px){.bonus{width:44px;height:51px}}@media (min-width:320px) and (max-width:480px){.main-menu-container>li>a{padding:18px}}@media (min-width:481px) and (max-width:767px){.main-menu-container>li>a{padding:30px}}p#breadcrumbs{color:#fff;text-align:center}.site-description li h4{color:#fff;line-height:26px;margin:5px;padding:0;text-align:left}.tada,.wobble{animation-iteration-count:infinite}@keyframes blinkings{0%{border:2px solid #fff}100%{border:2px solid #A29767}}span.faq-arrow{float:right;color:#fff}.fixed-footer{display:flex;justify-content:space-around;position:fixed;background:radial-gradient(circle 214px at 49.5% 54.2%,#201a1a 0,#171717 96%);padding:5px 0;left:0;right:0;bottom:0;z-index:99}.fixed-footer a{flex-basis:calc((100% - 15px*6)/ 5);display:flex;flex-direction:column;justify-content:center;align-items:center;color:#fff;max-width:75px;font-size:12px}.fixed-footer .center{transform:scale(1.5) translateY(-5px);background:center/contain no-repeat;background-color:inherit;border-radius:50%}.fixed-footer amp-img{max-width:30%;margin-bottom:5px}.tada{-webkit-animation-name:tada;animation-name:tada;-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both}@-webkit-keyframes tada{0%,100%{-webkit-transform:scale3d(1,1,1);transform:scale3d(1,1,1)}10%,20%{-webkit-transform:scale3d(.9,.9,.9) rotate3d(0,0,1,-3deg);transform:scale3d(.9,.9,.9) rotate3d(0,0,1,-3deg)}30%,50%,70%,90%{-webkit-transform:scale3d(1.1,1.1,1.1) rotate3d(0,0,1,3deg);transform:scale3d(1.1,1.1,1.1) rotate3d(0,0,1,3deg)}40%,60%,80%{-webkit-transform:scale3d(1.1,1.1,1.1) rotate3d(0,0,1,-3deg);transform:scale3d(1.1,1.1,1.1) rotate3d(0,0,1,-3deg)}}@keyframes tada{0%,100%{-webkit-transform:scale3d(1,1,1);transform:scale3d(1,1,1)}10%,20%{-webkit-transform:scale3d(.9,.9,.9) rotate3d(0,0,1,-3deg);transform:scale3d(.9,.9,.9) rotate3d(0,0,1,-3deg)}30%,50%,70%,90%{-webkit-transform:scale3d(1.1,1.1,1.1) rotate3d(0,0,1,3deg);transform:scale3d(1.1,1.1,1.1) rotate3d(0,0,1,3deg)}40%,60%,80%{-webkit-transform:scale3d(1.1,1.1,1.1) rotate3d(0,0,1,-3deg);transform:scale3d(1.1,1.1,1.1) rotate3d(0,0,1,-3deg)}}.wobble{-webkit-animation-name:wobble;animation-name:wobble;-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both}@-webkit-keyframes wobble{0%,100%{-webkit-transform:none;transform:none}15%{-webkit-transform:translate3d(-25%,0,0) rotate3d(0,0,1,-5deg);transform:translate3d(-25%,0,0) rotate3d(0,0,1,-5deg)}30%{-webkit-transform:translate3d(20%,0,0) rotate3d(0,0,1,3deg);transform:translate3d(20%,0,0) rotate3d(0,0,1,3deg)}45%{-webkit-transform:translate3d(-15%,0,0) rotate3d(0,0,1,-3deg);transform:translate3d(-15%,0,0) rotate3d(0,0,1,-3deg)}60%{-webkit-transform:translate3d(10%,0,0) rotate3d(0,0,1,2deg);transform:translate3d(10%,0,0) rotate3d(0,0,1,2deg)}75%{-webkit-transform:translate3d(-5%,0,0) rotate3d(0,0,1,-1deg);transform:translate3d(-5%,0,0) rotate3d(0,0,1,-1deg)}}@keyframes wobble{0%,100%{-webkit-transform:none;transform:none}15%{-webkit-transform:translate3d(-25%,0,0) rotate3d(0,0,1,-5deg);transform:translate3d(-25%,0,0) rotate3d(0,0,1,-5deg)}30%{-webkit-transform:translate3d(20%,0,0) rotate3d(0,0,1,3deg);transform:translate3d(20%,0,0) rotate3d(0,0,1,3deg)}45%{-webkit-transform:translate3d(-15%,0,0) rotate3d(0,0,1,-3deg);transform:translate3d(-15%,0,0) rotate3d(0,0,1,-3deg)}60%{-webkit-transform:translate3d(10%,0,0) rotate3d(0,0,1,2deg);transform:translate3d(10%,0,0) rotate3d(0,0,1,2deg)}75%{-webkit-transform:translate3d(-5%,0,0) rotate3d(0,0,1,-1deg);transform:translate3d(-5%,0,0) rotate3d(0,0,1,-1deg)}}
  </style>

  <script type='text/javascript' src='https://cdn.ampproject.org/v0.js' async></script>
  <script async custom-element="amp-analytics" src="https://cdn.ampproject.org/v0/amp-analytics-0.1.js"></script>
  <script async custom-element="amp-anim" src="https://cdn.ampproject.org/v0/amp-anim-0.1.js"></script>
  <script async custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js"></script>

</head>
<body>
 
<div class="navbar">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <div class="logomobi acenter">
                <span itemscope="itemscope" itemtype="http://schema.org/Brand"><a itemprop="url" href="https://t.ly/masbro.smkdata" title="slot gacor">
                  <a href="https://t.ly/masbro.smkdata" title="slot gacor"><amp-img src="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/7fae0c07-c3d4-4e08-6384-c0c4a8f53700/public" alt="Slot Server Internasional" width="125" height="32"/></a>
                    <meta itemprop="name" content="slot gacor"></a></span>
              </div>
            </div>
        </div>
    </div>
</div>
<div class="clear"></div>

    <div class="content">
        <div class="container">
            <div class="row mtop">
                <div class="col-md-4">
                    <div class="logo acenter">
                        <span itemscope="itemscope" itemtype="http://schema.org/Brand"><a itemprop="url" href="https://t.ly/masbro.smkdata" title="slot gacor">
                        <a href="https://t.ly/masbro.smkdata" title="slot gacor"><amp-img src="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/7fae0c07-c3d4-4e08-6384-c0c4a8f53700/public" alt="slot" width="108" height="32" layout="responsive"/></a>
                        <meta itemprop="name" content="slot gacor"></a></span>
                    </div>
                </div>       
       <div class="col-md-8">
        <div class="row logform">
          <div class="col-xs-6">
            <a href="https://t.ly/masbro.smkdata" target="_blank" rel="nofollow noreferrer"><span class="tron">DAFTAR</span></a>
          </div>
          <div class="col-xs-6">
            <a href="https://t.ly/masbro.smkdata" target="_blank" rel="nofollow noreferrer"><span class="tron">LOGIN</span></a>
          </div>
        </div>
      </div>
          </div>
    <div class="row">
      <div class="col-md-12 mt-3">
        <a href="https://t.ly/masbro.smkdata" rel="nofollow noreferrer" target="_blank"><button type="login" class="btn btn-daf"><?php echo $BRANDS ?> - Game Online Gacor Penghasil Uang Dengan Deposit 1000 Langsung Menang Besar</button></a>
      </div>
    </div>
  </div>  
</div>
<div class="container">


<div class="item-8 item-xs-12 m-b-1 slider-area owl-carousel">
  <amp-carousel width="1182"
    height="450"
    layout="responsive"
    type="slides"
    autoplay
    delay="4000">
    <amp-img src="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public"
    width="1182"
    height="450"
    layout="responsive"
    alt="slot gacor">
    <amp-img alt="slot gacor"
    fallback
    width="1182"
    height="450"
    layout="responsive"
    src="https://imagedelivery.net/y60h0y0W8HdUIr8UrHzWlg/07471edc-5565-43d0-88af-8dff2e8c5300/public"></amp-img>
    </amp-img>
  </amp-carousel>   
</div>
</div>
<div class="spacer"></div>
<div class="container">
<div class="table">
<table class="GACOR88" style="width:100%">
<thead>
<tr>
<th colspan="3">Tentang Situs Slot Gacor </th>
</tr>
</thead>
<tbody>
<tr>
<td style="padding: 10px;">Nama Situs</td>
<td style="padding: 10px;"><?php echo $BRANDS ?></td>
</tr>
<tr>
<td style="padding: 10px;">Minimal Deposit</td>
<td style="padding: 10px;">Rp10.000</td>
</tr>
<tr>
<td style="padding: 10px;">Metode Deposit</td>
<td style="padding: 10px;">Transfer Bank, OVO, Go-pay, Pulsa, DANA, Linkaja</td>
</tr>
<tr>
<td style="padding: 10px;">Mata Uang</td>
<td style="padding: 10px;">IDR (Indonesian Rupiah)</td>
</tr>
<tr>
<td style="padding: 10px;">Jam Operasional</td>
<td style="padding: 10px;">24 Jam Online</td>
</tr>
<tr>
<td style="padding: 10px;">Daftar Sekarang</td>
<td style="padding: 10px;"><a href="https://t.ly/masbro.smkdata" rel="nofollow noopener" target="_blank" title="Slot Server Internasional">Klik Disini</a></td>
</tr>
</tbody>
</table>
</div>
</div>
<br>
  <div class="container">
    <div class="copyleft acenter pb-2">
      <span>&copy; Copyright 2024 <a href="#"><?php echo $BRANDS ?></a> | Allright Reserved.</span>
    </div>
  </div>
<div class="fixed-footer">
  <a href="https://t.ly/masbro.smkdata" rel="nofollow noopener" target="_blank">
    <amp-img layout="intrinsic" height="75" width="75" src="https://imagedelivery.net/k2DekMlVuWYM0EWSwlREiw/e56f8bfd-c0c6-46c7-19e7-cd22b3c8db00/public" alt="Slot Demo Hari Ini"></amp-img>
    Bonus
  </a>
  <a href="https://t.ly/masbro.smkdata" rel="nofollow noopener" target="_blank" class="tada">
    <amp-img class="center" layout="intrinsic" height="50" width="50" src="https://imagedelivery.net/k2DekMlVuWYM0EWSwlREiw/cdaae5aa-9f1a-436d-433c-194817f6f400/public" alt="DAFTAR Deposit Pulsa"></amp-img>
    Daftar
  </a>
  <a href="https://t.ly/masbro.smkdata" rel="nofollow noopener" target="_blank" class="js_live_chat_link live-chat-link">
    <amp-img class="live-chat-icon" layout="intrinsic" height="75" width="75" src="https://imagedelivery.net/k2DekMlVuWYM0EWSwlREiw/17b932a0-3936-49b2-f532-4b956bf82300/public" alt="Live Chat Slot Gacor Deposit Pulsa"></amp-img>
    Live Chat
  </a>
</div>
</body>
</html>